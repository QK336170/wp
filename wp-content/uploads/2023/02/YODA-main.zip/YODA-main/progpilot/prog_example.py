import progpilot

prog_obj = progpilot.Progpilot()
result = prog_obj.run('/home/brian/test_shell.php')
print(result)