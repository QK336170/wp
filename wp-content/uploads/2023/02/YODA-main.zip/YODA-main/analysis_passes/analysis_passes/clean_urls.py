clean_urls =[
            "www.googleapis.com",
            "wordpress.com",
            "slack.com"
            ]
